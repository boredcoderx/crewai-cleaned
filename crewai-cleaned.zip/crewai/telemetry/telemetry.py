from __future__ import annotations

import asyncio
import json
import os
import platform
import warnings
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Optional


@contextmanager
def suppress_warnings():
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore")
        yield


with suppress_warnings():
    import pkg_resources


if TYPE_CHECKING:
    from crewai.crew import Crew
    from crewai.task import Task


class Telemetry:
    """A class to handle anonymous telemetry for the crewai package.

    The data being collected is for development purpose, all data is anonymous.

    There is NO data being collected on the prompts, tasks descriptions
    agents backstories or goals nor responses or any data that is being
    processed by the agents, nor any secrets and env vars.

    Users can opt-in to sharing more complete data using the `share_crew`
    attribute in the Crew class.
    """

    def __init__(self):
        return

    def set_tracer(self):
        return

    def _safe_telemetry_operation(self, operation):
        return

    def crew_creation(self, crew: Crew, inputs: dict[str, Any] | None):
        return

    def task_started(self, crew: Crew, task: Task):
        return

    def task_ended(self, span, task: Task, crew: Crew):
        return

    def tool_repeated_usage(self, llm: Any, tool_name: str, attempts: int):
        return

    def tool_usage(self, llm: Any, tool_name: str, attempts: int):
        return

    def tool_usage_error(self, llm: Any):
        return

    def individual_test_result_span(
        self, crew: Crew, quality: float, exec_time: int, model_name: str
    ):
        return


    def test_execution_span(
        self,
        crew: Crew,
        iterations: int,
        inputs: dict[str, Any] | None,
        model_name: str,
    ):
        return

    def deploy_signup_error_span(self):
        return
    
    def start_deployment_span(self, uuid: Optional[str] = None):
        return

    def create_crew_deployment_span(self):
        return

    def get_crew_logs_span(self, uuid: Optional[str], log_type: str = "deployment"):
        return

    def remove_crew_span(self, uuid: Optional[str] = None):
        return

    def crew_execution_span(self, crew: Crew, inputs: dict[str, Any] | None):
        return

    def end_crew(self, crew, final_string_output):
        return

    def _add_attribute(self, span, key, value):
        return

    def flow_creation_span(self, flow_name: str):
        return

    def flow_plotting_span(self, flow_name: str, node_names: list[str]):
        return

    def flow_execution_span(self, flow_name: str, node_names: list[str]):
        return
