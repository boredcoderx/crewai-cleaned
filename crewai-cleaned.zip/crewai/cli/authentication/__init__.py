from .main import AuthenticationCommand

__all__ = ["AuthenticationCommand"]
